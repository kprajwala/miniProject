<?php
?>
<!--DONOR LOGIN-REGISTRATION FORM-->
<html>
    <head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<title>Registration Form</title>
        <link rel="stylesheet" href="assets/css/Main.css">
        <script src="assets/js/jquery-1.10.2.min.js"></script>
        <script src="assets/js/JQUERY%20Main.js"></script>
		<style>
			body{
			background-image: url("assets/img/d-login2.jpg");
			background-repeat: no-repeat;
			background-size: cover;
			background-position: center;
			position: relative;
			overflow-y: hidden;
			}
			#back{
				text-color : black;
			}
		</style>
    </head>
    <body>
		<header>
		<div id="search-bar">
			<div class="container">
				<div class="row">
					<form action="#" name="search" class="col-xs-12">
						<input type="text" name="search" placeholder="Type and Hit Enter"><i id="search-close" class="fa fa-close"></i>
					</form>
				</div>
			</div>
		</div>
		
		<nav  class="navigation">
			<div class="container">
				<div class="row">
					
					<div class="logo-wrap col-md-3 col-xs-6">
						
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
							
									<li><a href="about-us.php">About Us</a></li>
									<li><a href="contact-us.php">Contact Us</a></li>
								
							
							<li>
								<a href="gallery.html">gallery</a>
							</li>
						</ul>
					</div>
					
				</div>
			</div>
			</nav>
			<a href="index.php" id="back"><b><h1><font color="white"><--Back</font></h1></b></a>
			</header>
			
		<form method="post" action="d-validate.php">
        <div id="box">
            <div id="main"></div>
            <div id="loginform">
                <h1>LOGIN</h1>
				<?php
				//echo "please";
				session_start();
				if((isset($_SESSION['reg'])) && $_SESSION['reg']=="true")
				{
					echo "Successfully registered...Please Login";
					$_SESSION['reg']="false";
				}
				if(isset($_SESSION['pass']) && $_SESSION['pass']=="true")
				{
					echo "Invalid password";
					$_SESSION['pass']="false";
				}
				if(isset($_SESSION['no_user']) && $_SESSION['no_user']=="true")
				{
					echo "No user available..";
					$_SESSION['no_user']="false";
				}
				if(isset($_SESSION['user_exists']) && $_SESSION['user_exists']=="true")
				{
					echo "User exists..Please login";
					$_SESSION['user_exists']="false";
				}
				?>
                <input type="email" placeholder="Email" name="email"/><br>
                <input type="password" placeholder="Password" name="pwd"/><br><br><br>
                <input type="submit" name="login" value="login"/>
            </div>
			</form>
			<form method="post" action="d-validate.php">
            <div id="signupform">
                <h1>REGISTER</h1>
                <input type="text" placeholder="Full Name" name="name" required/><br>
                <input type="email" placeholder="Email" name="email" required/><br>
                <input type="password" placeholder="Password" name="pwd" required/><br>
				<!--<input type="password" placeholder="Confirm Password" required/><br>-->
				<input type="text" placeholder="Address" name="address" required/><br>
				<input type="text" placeholder="Contact no" name="contact" required/><br>
                <input type="submit" name="register" value="register"/>
            </div>    
            <div id="login_msg">Already registered??</div>
            <div id="signup_msg">Want to register?</div>
            <button id="login_btn">LOGIN</button>
            <button id="signup_btn">REGISTER</button> 
        </div>
		</form>
		
    </body>
	
	
</html>
