<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="admin_login.css">
</head>
<body>

	<!-- header -->
	<header>
		<div id="search-bar">
			<div class="container">
				<div class="row">
					<form action="#" name="search" class="col-xs-12">
						<input type="text" name="search" placeholder="Type and Hit Enter"><i id="search-close" class="fa fa-close"></i>
					</form>
				</div>
			</div>
		</div>
		<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
							
									<li><a href="about-us.php">About Us</a></li>
									<li><a href="contact-us.php">Contact Us</a></li>
								
							
							<!--
							<li>
								<span>Blog</span>
								<ul class="submenu">
									<li><a href="blog-list.html">Blog List</a></li>
									<li><a href="blog-single.html">Blog Single</a></li>
								</ul>
							</li>-->
							<li>
								<a href="#">Admin</a>
							</li>
	

							<li>
								<a href="donor-login.php">Donor</a>
							</li>
							<li>
								<a href="contact-us.html">Volunteer</a>
							</li>
							<li>
								<a href="ngo.php">NGO</a>
							</li>
						</ul>
					</div>
					
				</div>
			</div>	
		</nav>
	</header>




	<!-- Banner -->
	<div class="page-banner">
		<div class="container">
			<div class="parallax-mask"></div>
			<div class="section-name">
				<h2>Contact Us</h2>
				<div class="short-text">
					<h5>Home<i class="fa fa-angle-double-right"></i>Contact Us</h5>
				</div>
			</div>
		</div>
	</div>
	
	
	<div class="contact-map-area">
		<div class="map-area" >

			<div id="map"></div>

		</div>
	</div>	
	
	<!-- contact wrapper -->
	<div class="contact-page-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<div class="row">
						<div class="col-sm-4 widget">
							<h4>Adress</h4>
							<i class="fa fa-map-marker"></i>
							<p>Adress no. 29, Some Street, Some Country</p>
						</div>
						<div class="col-sm-4 widget">
							<h4>Phone</h4>
							<i class="fa fa-phone"></i>
							<p>+40 712 345 678</p>
							<p>+40 712 345 876</p>
						</div>
						<div class="col-sm-4 widget">
							<h4>E-mail</h4>
							<i class="fa fa-envelope"></i>
							<p>spam.Kindness@mail.com</p>
							<p>spam.Kindness@mail.com</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<div class="comment-form-wrapper contact-from clearfix">
						<div class="widget-title ">
							<h4>Say Hello to Us</h4>
							<p>porro sunt dolor quia voluptatem. Dolore harum culpa</p>
						</div>
						<form class="comment-form row altered">
							<div class="field col-sm-4">
								<h4>Name</h4>
								<input type="text" name="first-name">
							</div>
							<div class="field col-sm-4">
								<h4>E-mail</h4>
								<input type="text" name="last-name">
							</div>
							<div class="field col-sm-4">
								<h4>Subject</h4>
								<input type="email" name="first-name">
							</div>
							<div class="field col-sm-12">
								<h4>Message</h4>
								<textarea name="message"></textarea>
							</div>
							<div class="field col-sm-4">
								<button class="btn btn-big btn-solid"><i class="fa fa-paper-plane"></i><span>Send Message</span></button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->
	<footer>
		<div class="footer-bar">
			<div class="container">
				<h5>Copyright ©2019 Online Charity System... All Rights Reserved</h5>
			</div>
		</div>
	</footer>
	<!-- Scripts -->
	<script type="text/javascript" src="assets/js/jquery2.min.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.meanmenu.js"></script>
	<script type="text/javascript" src="assets/js/progress-bar-appear.js"></script>
	<script type="text/javascript" src="assets/owl-carousel/owl.carousel.min.js"></script>
	<script type="text/javascript" src="assets/js/nivo-lightbox.min.js"></script>
	<script type="text/javascript" src="assets/js/isotope.min.js"></script>
	<script type="text/javascript" src="assets/js/countdown.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCBEypW1XtGLWpikFPcityAok8rhJzzWRw "></script>
	<script type="text/javascript" src="assets/js/gmaps.js"></script>
	<script type="text/javascript" src="assets/js/plugins.js"></script>
	<script type="text/javascript" src="assets/js/js.js"></script>

</body>
</html>